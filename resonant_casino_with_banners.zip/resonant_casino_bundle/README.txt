# Resonant Casino — banners bundle

В архиве:
- resonant_casino_fixed.py — бот с подключенными локальными баннерами
- banners/ — отдельные PNG для главного меню и игровых режимов

Структура баннеров:
main_menu.png, games.png, slots.png, darts.png, football.png, bowling.png, basketball.png, plinko.png, dice.png, special_games.png, mines.png, tower.png, knb.png, russian_roulette.png, roulette.png, 21.png, frog.png

Положите весь файл/папку banners рядом с resonant_casino_fixed.py при деплое. Код сначала ищет картинки в ./banners/, затем использует legacy-файлы в корне.
